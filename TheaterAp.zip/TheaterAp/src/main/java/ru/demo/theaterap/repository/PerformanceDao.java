package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.Performance;

public class PerformanceDao extends BaseDao<Performance>{
    public PerformanceDao()
    {
        super(Performance.class);
    }
}

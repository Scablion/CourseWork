package ru.demo.theaterap.model;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "places", schema = "theaters")
public class Place {

    @Id
    @Column(name = "place_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long PlaceId;

    @Column(name = "place_number", nullable = false)
    private int PlaceNumber;

    @Column(name = "row", nullable = false)
    private int Row;

    @Column(name = "is_empty", nullable = false)
    private boolean IsEmpty;

    @ManyToOne
    @JoinColumn(name = "place_type_id", nullable = false)
    private PlaceType PlaceTypeId;

    @ManyToOne
    @JoinColumn(name = "hall_id", nullable = false)
    private Hall IdHall;

    public boolean getIsEmpty() {
        return IsEmpty;
    }

    public void setIsEmpty(boolean isEmpty) {
        IsEmpty = isEmpty;
    }

    public int getRow() {
        return Row;
    }

    public void setRow(int row) {
        Row = row;
    }

    public Long getPlaceId() {
        return PlaceId;
    }

    public void setPlaceId(Long placeId) {
        PlaceId = placeId;
    }

    public Hall getHallId() {
        return IdHall;
    }

    public void setHallId(Hall hallId) {
        IdHall = hallId;
    }

    public int getPlaceNumber() {
        return PlaceNumber;
    }

    public void setPlaceNumber(int placeNumber) {
        PlaceNumber = placeNumber;
    }

    public PlaceType getPlaceTypeId() {
        return PlaceTypeId;
    }

    public void setPlaceTypeId(PlaceType placeTypeId) {
        PlaceTypeId = placeTypeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Place place = (Place) o;
        return Objects.equals(PlaceId, place.PlaceId) && Objects.equals(IdHall, place.IdHall) && Objects.equals(PlaceNumber, place.PlaceNumber) && Objects.equals(Row, place.Row) && Objects.equals(IsEmpty, place.IsEmpty) && Objects.equals(PlaceTypeId, place.PlaceTypeId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(PlaceId, IdHall, PlaceTypeId);
    }

    @Override
    public String toString() {
        return "PlaceTypeId='" +
                ", Ryad='" + Row + '\'' +
                ", PlaceNumber='" + PlaceNumber + '\'' +
                '}';
    }
}
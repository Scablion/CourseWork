package ru.demo.theaterap.service;

import ru.demo.theaterap.model.Schedule;
import ru.demo.theaterap.repository.ScheduleDao;

import java.util.List;

public class ScheduleService {
    private ScheduleDao scheduleDao = new ScheduleDao();

    public ScheduleService() {
    }

    public List<Schedule> findAll() {
        return scheduleDao.findAll();
    }

    public Schedule findOne(final long id) {
        return scheduleDao.findOne(id);
    }

    public void save(final Schedule entity)
    {
        if (entity == null)
            return;
        scheduleDao.save(entity);
    }

    public void update(final Schedule entity)
    {
        if (entity == null)
            return;
        scheduleDao.update(entity);
    }

    public void delete(final Schedule entity)
    {
        if (entity == null)
            return;
        scheduleDao.delete(entity);
    }

    public void deleteById(final Long id)
    {
        if (id == null)
            return;
        scheduleDao.deleteById(id);
    }
}
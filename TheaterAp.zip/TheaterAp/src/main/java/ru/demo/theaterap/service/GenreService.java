package ru.demo.theaterap.service;

import ru.demo.theaterap.model.Genre;
import ru.demo.theaterap.model.Performance;
import ru.demo.theaterap.repository.GenreDao;

import java.util.List;

public class GenreService {
    private static final GenreDao genreDao = new GenreDao();

    public GenreService() {
    }

    public static List<Genre> findAll() {
        return genreDao.findAll();
    }

    public Genre findOne(final long id) {
        return genreDao.findOne(id);
    }

    public void save(final Genre entity)
    {
        if (entity == null)
            return;
        genreDao.save(entity);
    }

    public void update(final Genre entity)
    {
        if (entity == null)
            return;
        genreDao.update(entity);
    }

    public void delete(final Genre entity)
    {
        if (entity == null)
            return;
        genreDao.delete(entity);
    }

    public void deleteById(final Long id)
    {
        if (id == null)
            return;
        genreDao.deleteById(id);
    }
}

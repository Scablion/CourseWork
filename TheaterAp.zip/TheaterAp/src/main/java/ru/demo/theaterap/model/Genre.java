package ru.demo.theaterap.model;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "genres", schema = "theater")
public class Genre {
    public Genre(){

    }
    @Id
    @Column(name = "genre_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long GenreId;

    @Column(name = "title", nullable = false)
    private String title;

    public Genre(long l, String все) {
    }

    public Long getGenreId() {
        return GenreId;
    }

    public void setGenreId(Long genreId) {
        GenreId = genreId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Genre genre = (Genre) o;
        return Objects.equals(GenreId, genre.GenreId) && Objects.equals(title, genre.title);
    }

    @Override
    public int hashCode() {
        return Objects.hash(GenreId, title);
    }

    @Override
    public String toString() {
        return title;
    }
}

package ru.demo.theaterap.model;

import jakarta.persistence.*;
import org.hibernate.Session;
import ru.demo.theaterap.util.HibernateSessionFactoryUtil;

import java.util.Objects;

@Entity
@Table(name = "place_types", schema = "theater")
public class PlaceType {

    @Id
    @Column(name = "type_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long typeId;

    @Column(name = "type_name", nullable = false, length = 50)
    private String type;

    @Column(name = "price", nullable = false)
    private double price;

    public Long getTypeId() {
        return typeId;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    public static double getPriceByTypeId(Long typeId) {
        // Получение Session из SessionFactory
        Session session = HibernateSessionFactoryUtil.getSessionFactory().openSession();

        // Начинаем транзакцию
        session.beginTransaction();

        // Выполняем поиск PlaceType по ID
        PlaceType placeType = session.get(PlaceType.class, typeId);

        // Завершаем транзакцию
        session.getTransaction().commit();

        // Закрываем сессию
        session.close();

        // Возвращаем цену
        if (placeType != null) {
            return placeType.getPrice();
        } else {
            return 0.0; // или можно выбросить исключение, если такого типа не существует
        }
    }


    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PlaceType placeType = (PlaceType) o;
        return Double.compare(price, placeType.price) == 0 && Objects.equals(typeId, placeType.typeId) && Objects.equals(type, placeType.type);
    }

    @Override
    public int hashCode() {
        return Objects.hash(typeId, type, price);
    }

    @Override
    public String toString() {
        return type;
    }
}

package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.Ticket;

public class TicketDao extends BaseDao<Ticket>{
    public TicketDao()
    {
        super(Ticket.class);
    }
}

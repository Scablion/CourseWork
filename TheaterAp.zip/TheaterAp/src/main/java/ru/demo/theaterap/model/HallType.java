package ru.demo.theaterap.model;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "hall_types", schema = "theater")
public class HallType {
    @Id
    @Column(name = "hall_type_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long hallTypeId;

    @Column(name = "hall_type_name", nullable = false, length = 50)
    private String hallType;

    public Long getHallTypeId() {
        return hallTypeId;
    }

    public void setHallTypeId(Long hallTypeId) {
        this.hallTypeId = hallTypeId;
    }

    public String getHallType() {
        return hallType;
    }

    public void setHallType(String hallType) {
        this.hallType = hallType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HallType hallType1 = (HallType) o;
        return Objects.equals(hallTypeId, hallType1.hallTypeId) && Objects.equals(hallType, hallType1.hallType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(hallTypeId, hallType);
    }

    @Override
    public String
    toString() {
        return hallType;
    }
}
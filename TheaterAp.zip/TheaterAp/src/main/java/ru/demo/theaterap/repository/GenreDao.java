package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.Genre;

public class GenreDao extends BaseDao<Genre>{
    public GenreDao()
    {
        super(Genre.class);
    }
}

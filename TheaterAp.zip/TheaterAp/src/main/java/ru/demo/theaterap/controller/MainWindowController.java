package ru.demo.theaterap.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import ru.demo.theaterap.TheatreAp;
import ru.demo.theaterap.model.Genre;
import ru.demo.theaterap.model.Performance;
import ru.demo.theaterap.model.Schedule;
import ru.demo.theaterap.service.GenreService;
import ru.demo.theaterap.service.PerformanceService;
import ru.demo.theaterap.service.ScheduleService;
import ru.demo.theaterap.util.Manager;

import java.io.IOException;
import java.net.URL;
import java.util.Comparator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import static ru.demo.theaterap.util.Manager.currentStage;

public class MainWindowController implements Initializable {

    public ListView ListViewPerformance;
    public TextField TextFieldSearch;
    public ComboBox ComboBoxGenre;
    public ComboBox ComboboxSort;
    public Button BtnPerformance;
    public Button BtnBack;
    public Label LabelInfo;
    private ScheduleService scheduleService = new ScheduleService();
    private int itemsCount;
    @FXML
    private Label LabelUser;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println(currentStage);
        LabelUser.setText(Manager.currentUser.getFirstName());
        List<Genre> genreList = GenreService.findAll();
        genreList.add(0, new Genre(0L, "Все"));
        ObservableList<Genre> genres = FXCollections.observableArrayList(genreList);
        ComboBoxGenre.setItems(genres);
        loadSchedules(null);
    }

    @FXML
    void TextFieldTextChanged(ActionEvent event) {
        filterData();
    }
    public void TextFieldSearchAction(ActionEvent actionEvent) {
        filterData();
    }

    public void ComboBoxGenreAction(ActionEvent actionEvent) {
//        ComboBox<Genre> ComboBoxGenre = new ComboBox<>();
//        Genre genre = ComboBoxGenre.getValue();
//        if (genre.getGenreId() == 0) {
//            loadSchedules(null);
//        } else {
//            loadSchedules(genre);
//        }
//        System.out.println(genre.getGenreId());
        filterData();
    }

    public void ComboboxSortAction(ActionEvent actionEvent) {
        filterData();
    }

    public void BtnPerformanceAction(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(TheatreAp.class.getResource("products-table-view.fxml"));

        Scene scene = null;
        try {
            scene = new Scene(fxmlLoader.load());
            scene.getStylesheets().add("base-styles.css");
            //Manager.secondStage.setScene(scene);

            //Manager.mainStage.show();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void BtnBackAction(ActionEvent actionEvent) {
    }

    public void loadSchedules(Genre genre) {
        ListViewPerformance.getItems().clear();
        List<Schedule> schedules = scheduleService.findAll();
        if (genre != null) {
            schedules = schedules.stream().filter(schedule -> schedule.getPerformanceId().getGenre().getGenreId().equals(genre.getGenreId())).collect(Collectors.toList());
        }
        for (Schedule schedule : schedules) {
            ListViewPerformance.getItems().add(schedule);
        }
        ListViewPerformance.setCellFactory(lv -> new ScheduleCell());
    }
    void filterData() {
        List<Schedule> schedules = scheduleService.findAll();
        itemsCount = schedules.size();
        if (!ComboBoxGenre.getSelectionModel().isEmpty()) {
            Genre genre = (Genre) ComboBoxGenre.getValue();
            if (genre.getGenreId() != 0) {
                schedules = schedules.stream().filter(schedule -> schedule.getPerformanceId().equals(genre.getGenreId())).collect(Collectors.toList());
            }
        }
        if (!ComboboxSort.getSelectionModel().isEmpty()) {
            String order = (String) ComboboxSort.getValue();
            if (order.equals("по возрастанию цены")) {
                schedules = schedules.stream().sorted(Comparator.comparing(Schedule::getPrice)).collect(Collectors.toList());
            }
            if (order.equals("по убыванию цены")) {
                schedules = schedules.stream().sorted(Comparator.comparing(Schedule::getPrice)).collect(Collectors.toList()).reversed();
            }
        }

        String searchText = TextFieldSearch.getText();
        if (!searchText.isEmpty()) {
            schedules = schedules.stream().filter(schedule -> schedule.getPerformanceId().getTitle().toLowerCase().contains(searchText.toLowerCase())).collect(Collectors.toList());
        }
        ListViewPerformance.getItems().clear();
        for (Schedule schedule : schedules) {
            ListViewPerformance.getItems().add(schedule);
        }
        ListViewPerformance.setCellFactory(lv -> new ScheduleCell());
        int filteredItemsCount = schedules.size();
        LabelInfo.setText("Всего записей " + filteredItemsCount + " из " + itemsCount);
    }
}

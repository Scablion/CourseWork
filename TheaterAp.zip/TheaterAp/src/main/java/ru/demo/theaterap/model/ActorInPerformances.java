package ru.demo.theaterap.model;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "actor_in_performances", schema = "theater")
public class ActorInPerformances {

    @Id
    @ManyToOne
    @JoinColumn(name = "actor_id", nullable = false)
    private Actor actorId;

    @Id
    @ManyToOne
    @JoinColumn(name = "performance_id", nullable = false)
    private Performance performance_id;

    public Actor getActorId() {
        return actorId;
    }

    public void setActorId(Actor actorId) {
        this.actorId = actorId;
    }

    public Performance getPerformance_id() {
        return performance_id;
    }

    public void setPerformance_id(Performance performance_id) {
        this.performance_id = performance_id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ActorInPerformances that = (ActorInPerformances) o;
        return Objects.equals(actorId, that.actorId) && Objects.equals(performance_id, that.performance_id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(actorId, performance_id);
    }

    @Override
    public String toString() {
        return
                "actorId=" + actorId +
                ", performance_id=" + performance_id;
    }
}

package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.ActorInPerformances;

public class ActorInPerformanceDao extends BaseDao<ActorInPerformances>{
    public ActorInPerformanceDao()
    {
        super(ActorInPerformances.class);
    }
}

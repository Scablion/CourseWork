package ru.demo.theaterap.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import ru.demo.theaterap.model.PlaceType;
import ru.demo.theaterap.model.Schedule;
import ru.demo.theaterap.repository.PlaceTypeDao;

import java.io.IOException;

public class PerformanceCellController {

    public ImageView PerformanceImage;
    public Label perfTitle;
    public Label description;
    public Label genre;
    public Label dateStart;
    public Label price;
    private PlaceType placeType;


    public void setSchedule(Schedule schedule) throws IOException {
        PerformanceImage.setImage(schedule.getPerformanceId().getPhoto());//Format image to byte in class performance
        description.setText(schedule.getPerformanceId().getDescription());
        perfTitle.setText(schedule.getPerformanceId().getTitle());
        genre.setText(schedule.getPerformanceId().getGenre().getTitle());
        dateStart.setText(schedule.getDateStart().toString());
        price.setText("Стандартное место\t" + ((int)schedule.getPrice() + (int)placeType.getPriceByTypeId(1L)) + " руб." + "\n" +
                "VIP место\t\t\t" + ((int)schedule.getPrice() + (int)placeType.getPriceByTypeId(2L)) + " руб." + "\n" +
                "Ложа\t\t\t\t" + ((int)schedule.getPrice() + (int)placeType.getPriceByTypeId(3L)) + " руб." + "\n");
    }

}


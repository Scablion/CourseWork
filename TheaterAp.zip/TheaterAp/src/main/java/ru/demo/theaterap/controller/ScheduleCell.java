package ru.demo.theaterap.controller;

import javafx.fxml.FXMLLoader;
import javafx.scene.control.ListCell;
import ru.demo.theaterap.TheatreAp;
import ru.demo.theaterap.model.Schedule;
import javafx.scene.Parent;

import java.io.IOException;

public class ScheduleCell extends ListCell<Schedule> {

    private final Parent root ;
    private PerformanceCellController controller ;

    public ScheduleCell() {
        try {
            FXMLLoader loader = new FXMLLoader(TheatreAp.class.getResource("performance-view.fxml"));
            root = loader.load();
            controller = loader.getController() ;
        } catch (IOException exc) {
            throw new RuntimeException(exc);
        }
    }

    @Override
    protected void updateItem(Schedule schedule, boolean empty) {
        super.updateItem(schedule, empty);
        if (empty || schedule == null) {
            setGraphic(null);
        } else {
            try {
                controller.setSchedule(schedule);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            setGraphic(root);
        }
    }
}

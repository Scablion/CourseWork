package ru.demo.theaterap.model;

import jakarta.persistence.*;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;
import ru.demo.theaterap.TheatreAp;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Objects;

@Entity
@Table(name = "performances", schema = "theater")
public class Performance {
    @Id
    @Column(name = "performance_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long performanceId;

    @Column(name = "title", nullable = false)
    private String title;

    @ManyToOne
    @JoinColumn(name = "genre", nullable = false)
    private Genre genre;

    @Column(name = "description", nullable = false)
    private String description;

    @Column(name = "longs", nullable = false)
    private int longs;

    @ManyToOne
    @JoinColumn(name = "author_id", nullable = false)
    private Author authorId;

    @Column(name = "premier", nullable = false)
    private LocalDate premier;

    @Column(name = "photo", nullable = false)
    private byte[] photo;

    public Long getPerformanceId() {
        return performanceId;
    }

    public void setPerformanceId(Long performanceId) {
        this.performanceId = performanceId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Genre getGenre() {
        return genre;
    }

    public void setGenre(Genre genre) {
        this.genre = genre;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getLongs() {
        return longs;
    }

    public void setLongs(int longs) {
        this.longs = longs;
    }

    public Author getAuthorId() {
        return authorId;
    }

    public void setAuthorId(Author authorId) {
        this.authorId = authorId;
    }

    public LocalDate getPremier() {
        return premier;
    }

    public void setPremier(LocalDate premier) {
        this.premier = premier;
    }

    public Image getPhoto() throws IOException {
        if (photo == null) {
            return new Image(Objects.requireNonNull(TheatreAp.class.getResourceAsStream("NaN.png")));

        }
        else {
            BufferedImage capture = ImageIO.read(new ByteArrayInputStream(photo));
            return SwingFXUtils.toFXImage(capture, null);
        }

    }

    public void setPhoto(Image img) throws IOException {
        BufferedImage buf = SwingFXUtils.fromFXImage(img, null);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(buf, "jpg", baos);
        byte[] bytes = baos.toByteArray();
        this.photo = bytes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Performance that = (Performance) o;
        return Objects.equals(performanceId, that.performanceId) && Objects.equals(title, that.title) && Objects.equals(genre, that.genre) && Objects.equals(description, that.description) && Objects.equals(longs, that.longs) && Objects.equals(authorId, that.authorId) && Objects.equals(premier, that.premier) && Objects.deepEquals(photo, that.photo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(performanceId, title, premier);
    }

    @Override
    public String toString() {
        return "Performance{" +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}

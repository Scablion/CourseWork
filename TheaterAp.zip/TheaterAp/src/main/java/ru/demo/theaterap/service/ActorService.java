package ru.demo.theaterap.service;


import ru.demo.theaterap.model.Actor;
import ru.demo.theaterap.repository.ActorDao;

import java.util.List;

public class ActorService {
    private ActorDao actorDao = new ActorDao();

    public ActorService() {
    }

    public List<Actor> findAll() {
        return actorDao.findAll();
    }

    public Actor findOne(final long id) {
        return actorDao.findOne(id);
    }

    public void save(final Actor entity)
    {
        if (entity == null)
            return;
        actorDao.save(entity);
    }

    public void update(final Actor entity)
    {
        if (entity == null)
            return;
        actorDao.update(entity);
    }

    public void delete(final Actor entity)
    {
        if (entity == null)
            return;
        actorDao.delete(entity);
    }

    public void deleteById(final Long id)
    {
        if (id == null)
            return;
        actorDao.deleteById(id);
    }
}

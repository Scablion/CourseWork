package ru.demo.theaterap.controller;

import javafx.event.ActionEvent;

public class PerformanceEditView {
    public void BtnSaveAction(ActionEvent actionEvent) {
    }

    public void BtnCancelAction(ActionEvent actionEvent) {
    }

    public void BtnLoadImageAction(ActionEvent actionEvent) {
    }
}

package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.Hall;

public class HallDao extends BaseDao<Hall>{
    public HallDao()
    {
        super(Hall.class);
    }
}

package ru.demo.theaterap.model;

import jakarta.persistence.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Table(name = "schedules", schema = "theater")
public class Schedule {
    @Id
    @Column(name = "schedule_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long scheduleId;

    @ManyToOne
    @JoinColumn(name = "performance_id", nullable = false)
    private Performance performanceId;

    @ManyToOne
    @JoinColumn(name = "hall_id", nullable = false)
    private Hall hallId;

    @Column(name = "date_start", nullable = false)
    private LocalDateTime dateStart;

    @Column(name = "price", nullable = false)
    private double price;

    public Long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Long scheduleId) {
        this.scheduleId = scheduleId;
    }

    public Performance getPerformanceId() {
        return performanceId;
    }

    public void setPerformanceId(Performance performanceId) {
        this.performanceId = performanceId;
    }

    public Hall getHallId() {
        return hallId;
    }

    public void setHallId(Hall hallId) {
        this.hallId = hallId;
    }

    public LocalDateTime  getDateStart() {
        return dateStart;
    }

    public void setDateStart(LocalDateTime  dateStart) {
        this.dateStart = dateStart;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Schedule schedules = (Schedule) o;
        return Double.compare(price, schedules.price) == 0 && Objects.equals(scheduleId, schedules.scheduleId) && Objects.equals(performanceId, schedules.performanceId) && Objects.equals(hallId, schedules.hallId) && Objects.equals(dateStart, schedules.dateStart);
    }

    @Override
    public int hashCode() {
        return Objects.hash(scheduleId, dateStart, price);
    }

    @Override
    public String toString() {
        return "Schedules{"+
                "dateStart='" + dateStart + '\'' +
                ", price=" + price +
                '}';
    }
}

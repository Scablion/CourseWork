package ru.demo.theaterap.service;

import ru.demo.theaterap.model.Performance;
import ru.demo.theaterap.repository.PerformanceDao;

import java.util.List;

public class PerformanceService {
    private final PerformanceDao performanceDao = new PerformanceDao();

    public PerformanceService() {
    }

    public List<Performance> findAll() {
        return performanceDao.findAll();
    }

    public Performance findOne(final long id) {
        return performanceDao.findOne(id);
    }

    public void save(final Performance entity)
    {
        if (entity == null)
            return;
        performanceDao.save(entity);
    }

    public void update(final Performance entity)
    {
        if (entity == null)
            return;
        performanceDao.update(entity);
    }

    public void delete(final Performance entity)
    {
        if (entity == null)
            return;
        performanceDao.delete(entity);
    }

    public void deleteById(final Long id)
    {
        if (id == null)
            return;
        performanceDao.deleteById(id);
    }
}

package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.Schedule;

public class ScheduleDao extends BaseDao<Schedule>{
    public ScheduleDao()
    {
        super(Schedule.class);
    }
}

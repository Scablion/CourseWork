package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.Place;

public class PlaceDao extends BaseDao<Place>{
    public PlaceDao()
    {
        super(Place.class);
    }
}

package ru.demo.theaterap;

import javafx.application.Application;
import javafx.stage.Stage;

import java.io.IOException;

import static ru.demo.theaterap.util.Manager.showStartStage;

public class TheatreAp extends Application {
    @Override
    public void start(Stage stage) throws IOException {

        showStartStage(stage, "login-view.fxml", "Авторизация");
    }

    public static void main(String[] args) {
        launch();
    }
}
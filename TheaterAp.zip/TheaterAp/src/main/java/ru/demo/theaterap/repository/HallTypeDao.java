package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.HallType;

public class HallTypeDao extends BaseDao<HallType>{
    public HallTypeDao()
    {
        super(HallType.class);
    }
}


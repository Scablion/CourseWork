package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.Role;

public class RoleDao extends BaseDao<Role>{
    public RoleDao()
    {
        super(Role.class);
    }
}

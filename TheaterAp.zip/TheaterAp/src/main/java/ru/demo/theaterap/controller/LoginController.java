package ru.demo.theaterap.controller;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import ru.demo.theaterap.model.User;

import java.util.List;
import java.util.Optional;

import ru.demo.theaterap.repository.UserDao;
import ru.demo.theaterap.util.Manager;

import static ru.demo.theaterap.util.Manager.*;

public class LoginController {

    UserDao userDao = new UserDao();
    @FXML
    private Button BtnCancel;

    @FXML
    private Button BtnOK;

    @FXML
    private PasswordField PasswordField;

    @FXML
    private TextField TextFieldUserName;

    public void btnOkOnAction(javafx.event.ActionEvent actionEvent) {
        List<User> users = userDao.findAll();
        Optional<User> user = users.stream().filter(user1 -> user1.getUsername().equals(TextFieldUserName.getText()) &&
                user1.getPassword().equals(PasswordField.getText())).findFirst();
        if (user.isEmpty()) {
            showErrorMessageBox("Не верный логин или пароль");
            return;
        }
        startStage.hide();
        showMainStage(user.get());
    }

    public void btnCancelOnAction(javafx.event.ActionEvent actionEvent) {
        boolean result = Manager.showExitWindow();
        if(result){
            Platform.exit();
        }
    }
}

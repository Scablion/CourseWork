package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.Author;

public class AuthorDao extends BaseDao<Author>{
    public AuthorDao()
    {
        super(Author.class);
    }
}

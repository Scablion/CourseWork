package ru.demo.theaterap.service;

import ru.demo.theaterap.model.Author;
import ru.demo.theaterap.repository.AuthorDao;

import java.util.List;

public class AuthorService {
    private AuthorDao authorDao = new AuthorDao();

    public AuthorService() {
    }

    public List<Author> findAll() {
        return authorDao.findAll();
    }

    public Author findOne(final long id) {
        return authorDao.findOne(id);
    }

    public void save(final Author entity)
    {
        if (entity == null)
            return;
        authorDao.save(entity);
    }

    public void update(final Author entity)
    {
        if (entity == null)
            return;
        authorDao.update(entity);
    }

    public void delete(final Author entity)
    {
        if (entity == null)
            return;
        authorDao.delete(entity);
    }

    public void deleteById(final Long id)
    {
        if (id == null)
            return;
        authorDao.deleteById(id);
    }
}

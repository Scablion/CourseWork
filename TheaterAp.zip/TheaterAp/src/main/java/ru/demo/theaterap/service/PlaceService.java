package ru.demo.theaterap.service;

import ru.demo.theaterap.model.Place;
import ru.demo.theaterap.repository.PlaceDao;

import java.util.List;

public class PlaceService {
    private PlaceDao placeDao = new PlaceDao();

    public PlaceService() {
    }

    public List<Place> findAll() {
        return placeDao.findAll();
    }

    public Place findOne(final long id) {
        return placeDao.findOne(id);
    }

    public void save(final Place entity)
    {
        if (entity == null)
            return;
        placeDao.save(entity);
    }

    public void update(final Place entity)
    {
        if (entity == null)
            return;
        placeDao.update(entity);
    }

    public void delete(final Place entity)
    {
        if (entity == null)
            return;
        placeDao.delete(entity);
    }

    public void deleteById(final Long id)
    {
        if (id == null)
            return;
        placeDao.deleteById(id);
    }
}
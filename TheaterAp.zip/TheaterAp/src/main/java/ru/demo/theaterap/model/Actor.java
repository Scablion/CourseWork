package ru.demo.theaterap.model;

import jakarta.persistence.*;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;
import ru.demo.theaterap.TheatreAp;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

@Entity
@Table(name = "actors", schema = "theater")
public class Actor {
    @Id
    @Column(name = "actor_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String actorId;

    @Column(name = "first_name", nullable = false)
    private String firstName;

    @Column(name = "family", nullable = false)
    private String secondName;

    @ManyToOne
    @JoinColumn(name = "role_id", nullable = false)
    private Role password;

    @Column(name = "photo", nullable = false)
    private byte[] photo;

    public String getActorId() {
        return actorId;
    }

    public void setActorId(String actorId) {
        this.actorId = actorId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public Role getPassword() {
        return password;
    }

    public void setPassword(Role password) {
        this.password = password;
    }

    public Image getPhoto() throws IOException {
        if (photo == null)
            return new Image(Objects.requireNonNull(TheatreAp.class.getResourceAsStream("ru/demo/theaterap/NaN.png")));
        BufferedImage capture = ImageIO.read(new ByteArrayInputStream(photo));
        return SwingFXUtils.toFXImage(capture, null);
    }

    public void setPhoto(Image img) throws IOException {
        BufferedImage buf = SwingFXUtils.fromFXImage(img, null);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(buf, "jpg", baos);
        byte[] bytes = baos.toByteArray();
        this.photo = bytes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Actor actor = (Actor) o;
        return Objects.equals(actorId, actor.actorId) && Objects.equals(firstName, actor.firstName) && Objects.equals(secondName, actor.secondName) && Objects.equals(password, actor.password) && Objects.deepEquals(photo, actor.photo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(actorId, password, Arrays.hashCode(photo));
    }
}

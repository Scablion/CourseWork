package ru.demo.theaterap.model;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "halls", schema = "theater")
public class Hall {

    @Id
    @Column(name = "hall_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long HallId;

    @Column(name = "number_hall", nullable = false)
    private int NumberHall;

    @Column(name = "count_places", nullable = false)
    private int CountPlaces;

    @ManyToOne
    @JoinColumn(name = "hall_type", nullable = false)
    private HallType HallType;

    public Long getHallId() {
        return HallId;
    }

    public void setHallId(Long hallId) {
        HallId = hallId;
    }

    public int getNumberHall() {
        return NumberHall;
    }

    public void setNumberHall(int numberHall) {
        NumberHall = numberHall;
    }

    public int getCountPlaces() {
        return CountPlaces;
    }

    public void setCountPlaces(int countPlaces) {
        CountPlaces = countPlaces;
    }

    public ru.demo.theaterap.model.HallType getHallType() {
        return HallType;
    }

    public void setHallType(ru.demo.theaterap.model.HallType hallType) {
        HallType = hallType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Hall hall = (Hall) o;
        return Objects.equals(HallId, hall.HallId) && Objects.equals(NumberHall, hall.NumberHall) && Objects.equals(CountPlaces, hall.CountPlaces) && Objects.equals(HallType, hall.HallType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(HallId, NumberHall);
    }

    @Override
    public String toString() {
        return NumberHall + " " + HallType;
    }
}
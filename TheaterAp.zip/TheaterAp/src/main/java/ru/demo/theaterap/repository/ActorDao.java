package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.Actor;

public class ActorDao extends BaseDao<Actor>{
    public ActorDao()
    {
        super(Actor.class);
    }
}

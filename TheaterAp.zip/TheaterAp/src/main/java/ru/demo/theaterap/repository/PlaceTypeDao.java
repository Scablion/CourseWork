package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.PlaceType;

public class PlaceTypeDao extends BaseDao<PlaceType>{
    public PlaceTypeDao(){
        super(PlaceType.class);
    }
}

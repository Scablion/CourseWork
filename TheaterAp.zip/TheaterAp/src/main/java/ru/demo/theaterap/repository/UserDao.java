package ru.demo.theaterap.repository;

import ru.demo.theaterap.model.User;

public class UserDao extends BaseDao<User>{

    public UserDao()
    {
        super(User.class);
    }
}

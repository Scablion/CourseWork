package ru.demo.theaterap.controller;

import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.input.InputMethodEvent;

public class PerformanceTableView {
    public TableColumn TableColumnPhoto;
    public TableView TableViewPerformance;
    public TextField TextFieldSearch;
    public ComboBox ComboBoxGenre;
    public ComboBox ComboBoxSort;
    public TableColumn TableColumnTitle;
    public TableColumn TableColumnGenre;
    public TableColumn TableColumnDescription;
    public TableColumn TableColumnLongs;
    public TableColumn TableColumnAuthor;
    public TableColumn TableColumnPremier;
    public Label LabelInfo;

    public void BtnAddAction(ActionEvent actionEvent) {
    }

    public void BtnUpdateAction(ActionEvent actionEvent) {
    }

    public void BtnDeleteAction(ActionEvent actionEvent) {
    }

    public void BtnBackAction(ActionEvent actionEvent) {
    }

    public void TextFieldSearchAction(ActionEvent actionEvent) {
    }

    public void TextFieldTextChanged(InputMethodEvent inputMethodEvent) {
    }

    public void ComboBoxSortAction(ActionEvent actionEvent) {
    }

    public void ComboBoxGenreAction(ActionEvent actionEvent) {
    }
}

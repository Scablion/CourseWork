package ru.demo.theaterap.model;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "tickets", schema = "theater")
public class Ticket {
    @Id
    @Column(name = "ticket_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ticketId;

    @ManyToOne
    @JoinColumn(name = "schedule_id", nullable = false)
    private Schedule scheduleId;

    @ManyToOne
    @JoinColumn(name = "place_id", nullable = false)
    private Place placeId;

    @ManyToOne
    @JoinColumn(name = "buyer_id", nullable = false)
    private User buyerId;

    public Long getTicketId() {
        return ticketId;
    }

    public void setTicketId(Long ticketId) {
        this.ticketId = ticketId;
    }

    public Schedule getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Schedule scheduleId) {
        this.scheduleId = scheduleId;
    }

    public Place getPlaceId() {
        return placeId;
    }

    public void setPlaceId(Place placeId) {
        this.placeId = placeId;
    }

    public User getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(User buyerId) {
        this.buyerId = buyerId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Ticket ticket = (Ticket) o;
        return Objects.equals(ticketId, ticket.ticketId) && Objects.equals(scheduleId, ticket.scheduleId) && Objects.equals(placeId, ticket.placeId) && Objects.equals(buyerId, ticket.buyerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ticketId, scheduleId, placeId, buyerId);
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "Номер билета=" + ticketId +
                ", scheduleId=" + scheduleId +
                ", место=" + placeId +
                ", покупатель= id:" + buyerId +
                '}';
    }
}

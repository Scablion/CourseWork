module ru.demo.theaterap {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.naming;
    requires org.postgresql.jdbc;
    requires org.hibernate.orm.core;
    requires jakarta.persistence;
    requires javafx.swing;
    opens ru.demo.theaterap.model to org.hibernate.orm.core, javafx.base;
    opens ru.demo.theaterap to javafx.fxml;
    exports ru.demo.theaterap;
    exports ru.demo.theaterap.model;
    exports ru.demo.theaterap.controller;
    opens ru.demo.theaterap.controller to javafx.fxml;
}